
import os
import logging
from telegram import Update, ForceReply
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

# راه‌اندازی لاگ
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_html(
        rf"سلام {user.mention_html()}! 🎤 لطفاً فایل صوتی جلسه‌ات رو بفرست، من تبدیلش می‌کنم.",
        reply_markup=ForceReply(selective=True),
    )

async def handle_audio(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("در حال دریافت فایل صوتی...⏳")

    # دانلود فایل
    file = await update.message.voice.get_file() if update.message.voice else await update.message.audio.get_file()
    file_path = await file.download_to_drive()

    await update.message.reply_text("در حال تبدیل صدا به متن و خلاصه‌سازی...")

    # فراخوانی API (شبیه‌سازی شده)
    summary = "📄 خلاصه جلسه:
- موضوع مهم ۱
- موضوع مهم ۲

📝 صورتجلسه:
فلان افراد صحبت کردند..."

    await update.message.reply_text(summary)

def main() -> None:
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, handle_audio))

    app.run_polling()

if __name__ == "__main__":
    main()
